# ClassChat 2.0 — Roadmap

## 1. Video calling
- Add one-to-one (or group) video calls between users.
- Likely approach: WebRTC (with a signaling channel via existing messaging or a small real-time layer).

---

## 2. Updated messaging
- **Delete** — Users can delete their own messages.
- **Reply** — Reply to a specific message (thread or inline reply).
- **Attachments (all max 5MB):**
  - **Images** — Already supported; enforce 5MB limit.
  - **Files** — New: allow generic file uploads in DMs.
  - **Videos** — New: allow video uploads in DMs (max 5MB).

---

## 3. Updated posting
- **Delete** — Users can delete their own posts (if not already).
- **Attachments (all max 5MB):**
  - **Images** — Already supported; enforce 5MB limit.
  - **Files** — New: attach files to posts (max 5MB).
  - **Videos** — New: attach videos to posts (max 5MB).

---

## 4. Remade staff dashboard
- **Current issues:** Layout/sizing breaks when content is large; delete button gets hidden and area isn’t scrollable; only post deletion works reliably.
- **Goals:**
  - Redesign layout so long messages/posts don’t hide actions.
  - Make content areas scrollable so the delete (and other) buttons are always accessible.
  - Fix any broken staff actions so dashboard is fully usable.

---

## Suggested implementation order (to be refined)
1. **Staff dashboard** — Unblock daily use and moderation.
2. **Messaging updates** — Delete, reply, images 5MB, files 5MB, videos 5MB.
3. **Posting updates** — Delete, images 5MB, files 5MB, videos 5MB.
4. **Video calling** — Largest feature; can build after messaging is solid.

---

*No implementation yet; this is the 2.0 feature list and plan.*
