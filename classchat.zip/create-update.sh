#!/usr/bin/env bash
# Create update.zip from repo root (app files only). Run from repo root.
# Extracts to /home/host/classchatnode when you run ./place on the server.
# Excludes: node_modules, data, uploads, .git, *.zip, classchatnode subfolder.
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
ZIP_PATH="$SCRIPT_DIR/update.zip"

echo "Creating update.zip from repo root ..."
rm -f "$ZIP_PATH"
zip -rq "$ZIP_PATH" . \
  -x "node_modules/*" \
  -x "data/*" \
  -x "public/uploads/*" \
  -x ".git/*" \
  -x "*.zip" \
  -x "classchatnode/*" \
  -x "app.log"
echo "Saved to $ZIP_PATH"
echo "Copy update.zip and place to the server, then run: ./place"
